## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T)
library(Binomial)

## ------------------------------------------------------------------------
mean <- bin_mean(trials = 10, prob = 0.5)
mode <- bin_mode(trials = 10, prob = 0.5)
kurtosis <- bin_kurtosis(trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
pdf <- bin_distribution(trials = 10, prob = 0.5)
cdf <- bin_cumulative(trials = 10, prob = 0.5)
sum <- bin_variable(trials = 10, prob = 0.5)

## ---- fig.show='hold'----------------------------------------------------
plot(cdf) #plots CDF function

summary(sum) #shows detailed summary



